import { APIEmbed, Client, Collection, EmbedBuilder, EmbedData, HexColorString, REST } from "discord.js"
import { Command } from "../types/Command";
import { BOT_TOKEN, EMBED_COLOR } from "../config";
import fs from "fs";
import { Event } from "../types/Event";

class Bot extends Client {
    public commands: Collection<string, Command> = new Collection();
    public events: Collection<string, Event> = new Collection();

    async start() {
        this.rest = new REST({ version: "10" }).setToken(BOT_TOKEN);
        this.login(BOT_TOKEN);

        // Load commands from file
        const commandFiles = fs.readdirSync(`${__dirname}/commands`).filter(file => file.endsWith('.js') || file.endsWith('.ts'));
        for (const file of commandFiles) {
            const command: Command = await import(`${__dirname}/commands/${file}`)
            if ("data" in command && "run" in command) {
                global.bot.commands.set(command.data.name, command);

                if (process.env.DEV_MODE) {
                    global.logger.info(`Loaded command: ${command.data.name}`);
                }
            } else {
                global.logger.error(
                    `[WARNING] The command at ${file} is missing a required "data" or "execute" property.`
                );
            }
        }

        // Load event handlers from file
        const eventsFiles = fs.readdirSync(`${__dirname}/events`).filter(file => file.endsWith('.js') || file.endsWith('.ts'));
        for (const file of eventsFiles) {
            const event: Event = await import(`${__dirname}/events/${file}`)
            if ("name" in event && "run" in event) {
                this.events.set(event.name, event);

                // @ts-ignore
                this.on(event.name, event.run.bind(null, this));

                if (process.env.DEV_MODE) {
                    global.logger.info(`Loaded event: ${event.name}`);
                }
            } else {
                global.logger.error(
                    `[WARNING] The command at ${file} is missing a required "name" or "run" property.`
                );
            }
        }

    }

    public createEmbed(data: EmbedData | APIEmbed, botAvatar?: boolean): APIEmbed {
        let builder = new EmbedBuilder(data)
        if (!data.thumbnail && botAvatar) {
            builder.setThumbnail(this.user!.avatarURL());
        }

        // builder.setTimestamp();
        if (!data.color) builder.setColor(EMBED_COLOR as HexColorString);

        return builder.data
    }

    public unauthorizedEmbed(): APIEmbed {
        return this.createEmbed({
            title: ":x: Unauthorized",
            description: "You are not authorized to use this command"
        })
    }
}

export default Bot