import { Attachment, AttachmentBuilder, PermissionFlagsBits, SlashCommandBuilder, TextChannel, WebhookClient } from "discord.js"
import { CommandFunc } from "../../types/Command"
import { getRandomValue } from "../../utils/rand"
import { syncEvents } from "../../jobs/events"
import { WEBHOOK_URL } from "../../config"
import { userHasPermissions } from "../../utils/permissions"

export const data = new SlashCommandBuilder()
    .setName("start")
    .setDescription("Start event")
    .setDMPermission(false)
    .addChannelOption(option =>
        option
            .setName("channel")
            .setDescription("Channel where the event will be created")
            .setRequired(true)
    )
    .addBooleanOption(option =>
        option
            .setName("webhook")
            .setDescription("Send webhook with the event")
            .setRequired(true)
    )
    .addIntegerOption(option =>
        option
            .setName("min")
            .setDescription("Minimum range of numbers")
            .setRequired(true)
    )
    .addIntegerOption(option =>
        option
            .setName("max")
            .setDescription("Maximum range of numbers")
            .setRequired(true)
    )
    .addStringOption(option =>
        option
            .setName("item")
            .setDescription("Name of the item")
            .setRequired(true)
    )
    .addIntegerOption(option =>
        option
            .setName("interval")
            .setDescription("Hint interval in minutes")
            .setRequired(true)
    )

export const run: CommandFunc = async (client, inter) => {
    // check if interaction is done in a guild
    if (!inter.inGuild()) {
        return inter.reply({ embeds: [client.createEmbed({ title: "⚠ This command can only be used in a server" })], ephemeral: true })
    }

    // check if user has permission administrator
    if (!await userHasPermissions(inter)) {
        // return inter.reply({ content: "You don't have permission to use this command", ephemeral: true })
        return inter.reply({ embeds: [client.unauthorizedEmbed()], ephemeral: true })
    }

    await inter.deferReply({ ephemeral: true })

    const channel = inter.options.getChannel("channel")!
    const min = inter.options.getInteger("min")!;
    const max = inter.options.getInteger("max")!;
    const randomValue = getRandomValue(min, max);

    const event = await global.database.event.create({
        data: {
            guildID: inter.guildId!,
            channelID: channel.id,
            sendWebhook: inter.options.getBoolean("webhook")!,
            min,
            max,
            value: randomValue,
            item: inter.options.getString("item")!,
            hintInterval: inter.options.getInteger("interval")!,
            leftHintInterval: inter.options.getInteger("interval")!
        }
    })

    // sync events cache
    syncEvents()

    await inter.editReply({
        embeds: [client.createEmbed({
            title: "Event created!",
            description: `Event ID: ${event.id}`,
            fields: [
                {
                    name: "Item",
                    value: event.item,
                    inline: true
                },
                {
                    name: "Range",
                    value: `${min} - ${max}`,
                    inline: true
                },
                {
                    name: "Value",
                    value: `||${randomValue}||`,
                    inline: true
                }
            ]
        })]
    })

    const imageAttachment = new AttachmentBuilder("./assets/guessTheNumber.jpg", { name: "image.jpg" })
    await (channel as TextChannel).send({
        files: [imageAttachment],
        embeds: [client.createEmbed({
            title: "Event started!",
            description: `New event! Guess the number of ${event.item} !!\nRange: ${min} - ${max}`,
            image: {
                url: "attachment://image.jpg"
            }
        })]
    })

    if (event.sendWebhook && WEBHOOK_URL != "") {
        const webhookClient = new WebhookClient({
            url: WEBHOOK_URL
        })

        await webhookClient.send({
            embeds: [client.createEmbed({
                title: "Event created!",
                description: `Event ID: ${event.id}`,
                fields: [
                    {
                        name: "Channel",
                        value: `<#${event.channelID}>`,
                        inline: true
                    },
                    {
                        name: "Item",
                        value: event.item,
                        inline: true
                    },
                    {
                        name: "Range",
                        value: `${min} - ${max}`,
                        inline: true
                    },
                    {
                        name: "Value",
                        value: `||${randomValue}||`,
                        inline: true
                    },
                    {
                        name: "Interval",
                        value: `${event.hintInterval} minutes`,
                        inline: true
                    }
                ]
            })]
        })
    }
}
