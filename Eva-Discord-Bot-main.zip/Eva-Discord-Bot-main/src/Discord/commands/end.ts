import { PermissionFlagsBits, SlashCommandBuilder, TextChannel, WebhookClient } from "discord.js";
import { AutocompleteFunc, CommandFunc } from "../../types/Command";
import { syncEvents } from "../../jobs/events";
import { WEBHOOK_URL } from "../../config";
import { userHasPermissions } from "../../utils/permissions";

export const data = new SlashCommandBuilder()
    .setName("end")
    .setDescription("Ends an event")
    .setDMPermission(false)
    .addStringOption(option =>
        option
            .setName("id")
            .setDescription("Event ID")
            .setAutocomplete(true)
            .setRequired(true)
    )

export const run: CommandFunc = async (client, inter) => {
    // check if interaction is done in a guild
    if (!inter.inGuild()) {
        return inter.reply({ embeds: [client.createEmbed({ title: "⚠ This command can only be used in a server" })], ephemeral: true })
    }

    // check if user has permission administrator
    if (!await userHasPermissions(inter)) {
        return inter.reply({ embeds: [client.unauthorizedEmbed()], ephemeral: true })
    }

    await inter.deferReply({ ephemeral: true })

    var eventData = await global.database.event.findUnique({
        where: {
            id: parseInt(inter.options.getString("id")!)
        }
    })

    if (!eventData || eventData.guildID != inter.guildId) {
        return inter.editReply({ embeds: [client.createEmbed({ title: "⚠ No event found" })] })
    }

    await global.database.event.delete({
        where: {
            id: eventData.id
        }
    })

    // sync events cache
    syncEvents()

    const channel = client.channels.cache.get(eventData.channelID) || await client.channels.fetch(eventData.channelID)
    if (channel) {
        await (channel as TextChannel).send({
            embeds: [client.createEmbed({
                title: "Event ended!",
                description: `Event was ended by <@${inter.user.id}>`,
            })]
        })
    }

    if (eventData.sendWebhook && WEBHOOK_URL != "") {
        const webhookClient = new WebhookClient({
            url: WEBHOOK_URL
        })

        await webhookClient.send({
            embeds: [client.createEmbed({
                title: "Event ended!",
                description: `Event was ended by <@${inter.user.id}>`,
                fields: [
                    {
                        name: "ID",
                        value: `${eventData.id}`,
                        inline: true
                    },
                    {
                        name: "Item",
                        value: eventData.item,
                        inline: true
                    },
                    {
                        name: "Range",
                        value: `${eventData.min} - ${eventData.max}`,
                        inline: true
                    },
                    {
                        name: "Value",
                        value: `||${eventData.value}||`,
                        inline: true
                    }
                ]
            })]
        })
    }

    return inter.editReply({ embeds: [client.createEmbed({ title: "✅ Event ended" })] })
}

export const autocomplete: AutocompleteFunc = async (client, inter) => {
    if (!inter.inGuild()) {
        return inter.respond([])
    }

    // check if user has permission administrator
    if (!await userHasPermissions(inter)) {
        return inter.respond([])
    }

    const focusedValue = inter.options.getFocused();

    const events = await global.database.event.findMany({
        where: {
            guildID: inter.guildId!
        },
    });

    return inter.respond(events.map(event => {
        const channelName = (client.channels.cache.get(event.channelID) as TextChannel)?.name || ""
        return {
            name: `ID: ${event.id.toString()} | Item: ${event.item} | Channel: ${event.channelID}${channelName ? ` - ${channelName}` : ""}`,
            value: event.id.toString()
        }
    }).filter(option => {
        return option.name.toLowerCase().includes(focusedValue.toLowerCase())
    }).slice(0, 25));
}