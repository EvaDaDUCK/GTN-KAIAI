import { Events } from "discord.js";
import { RunFunc } from "../../types/Event";

export const name: string = Events.InteractionCreate;

export const run: RunFunc = async (client, interaction) => {
    if (interaction.isChatInputCommand()) {
        const command = client.commands.get(interaction.commandName);
        if (command) {
            try {
                if (process.env.DEV_MODE) {
                    global.logger.info(`${interaction.user.tag} executed command ${interaction.commandName}`);
                }

                await command.run(client, interaction);
            } catch (error) {
                global.logger.error(`Error executing command ${interaction.commandName}: ${error}`);

                if (interaction.replied) {
                    await interaction.editReply({ content: 'There was an error while executing this command!' });
                } else {
                    await interaction.reply({ content: 'There was an error while executing this command!', ephemeral: true });
                }
            }
        }

        return
    }

    if (interaction.isAutocomplete()) {
        const command = client.commands.get(interaction.commandName);
        if (command) {
            try {
                if (process.env.DEV_MODE) {
                    global.logger.info(`${interaction.user.tag} executed auto-complete command ${interaction.commandName}`);
                }

                await command.autocomplete(client, interaction);
            } catch (error) {
                global.logger.error(`Error executing auto-complete command ${interaction.commandName}: ${error}`);
            }
        }

        return
    }
};
