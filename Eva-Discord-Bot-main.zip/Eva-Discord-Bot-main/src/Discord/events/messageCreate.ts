import { Events, Message, WebhookClient } from "discord.js";
import { RunFunc } from "../../types/Event";
import { CORRECT_ANSWER_REACTION, WEBHOOK_URL } from "../../config";
import { syncEvents } from "../../jobs/events";

export const name: string = Events.MessageCreate;

export const run: RunFunc = async (client, message: Message) => {
  if (message.inGuild()) {
    if (global.events.has(message.channelId)) {
      const event = global.events.get(message.channelId)!;
      if (event.value.toString() === message.content) {
        await message.react(CORRECT_ANSWER_REACTION)
        await message.channel.send({
          content: `||<@${message.author.id}>||`,
          embeds: [client.createEmbed({
            title: `:tada: Congratulations ${message.author.displayName}!`,
            description: `Congratulations for guessing the correct number!\nThe number was **${event.value}**`,
            thumbnail: { url: message.author.displayAvatarURL() }
          })]
        });

        var eventData = await global.database.event.findUnique({
          where: {
            id: event.id
          }
        }).catch(() => { });

        await global.database.event.delete({
          where: {
            id: event.id
          }
        }).catch(() => { });

        // sync events cache
        syncEvents()

        if (eventData?.sendWebhook && WEBHOOK_URL != "") {
          const webhookClient = new WebhookClient({
            url: WEBHOOK_URL
          })

          await webhookClient.send({
            embeds: [client.createEmbed({
              title: "Event winner!",
              description: `<@${message.author.id}> guessed the correct number!\nUser display name: \`${message.author.displayName}\``,
              fields: [
                {
                  name: "Item",
                  value: eventData.item,
                  inline: true
                },
                {
                  name: "Guessed Number",
                  value: eventData.value.toString(),
                  inline: true
                }
              ],
              thumbnail: { url: message.author.displayAvatarURL() }
            })]
          })
        }
      }
    }
  }
};
