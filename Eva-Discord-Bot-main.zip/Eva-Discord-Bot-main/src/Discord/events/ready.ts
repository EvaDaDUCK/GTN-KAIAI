import { Events, Routes } from "discord.js";
import { RunFunc } from "../../types/Event";

export const name: string = Events.ClientReady;

export const run: RunFunc = async (client) => {
  global.logger.success(`Logged in as ${client.user?.tag}`);

  try {
    // @ts-ignore
    let ret: Array<any> =await client.rest.put(Routes.applicationCommands(client.user!.id), {
        body: client.commands.map(command => command.data.toJSON())
    });

    global.logger.success(
      `Registered ${ret.length} bot commands`,
    );
  } catch (error) {
    global.logger.error("Couldn't register slash commands! " + error);
  }
};
