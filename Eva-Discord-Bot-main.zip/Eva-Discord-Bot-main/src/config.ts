import * as dotenv from "dotenv";

dotenv.config();

export const DATABASE_URL = process.env.DATABASE_URL!;
export const BOT_TOKEN = process.env.BOT_TOKEN!;
export const EMBED_COLOR = process.env.EMBED_COLOR!;

export const WEBHOOK_URL = process.env.WEBHOOK_URL || "";
export const CORRECT_ANSWER_REACTION = process.env.CORRECT_ANSWER_REACTION || "✅";

export const ALLOWED_ROLES: Array<string> = process.env.ALLOWED_ROLES?.split(",") || [];
// export const DEV_MODE = process.env.DEV_MODE === "true";