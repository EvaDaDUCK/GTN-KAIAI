import Bot from "../Discord/Discord";

export interface RunFunc {
  (client: Bot, ...args: any[]): Promise<unknown>; // Note: need to change this
}

export interface Event {
  name: string;
  run: RunFunc;
}
