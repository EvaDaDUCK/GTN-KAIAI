export interface Job {
    runOnce?: boolean,
    interval: string,
    run: any
}