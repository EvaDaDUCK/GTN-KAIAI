import {
    AutocompleteInteraction,
    ButtonInteraction,
    CacheType,
    ChatInputCommandInteraction,
    ModalSubmitInteraction,
    SlashCommandBuilder,
  } from "discord.js";
  import Bot from "../Discord/Discord";
  
  export type InteractionType =
    | ChatInputCommandInteraction<CacheType>
    | ModalSubmitInteraction<CacheType>
    | ButtonInteraction<CacheType>;
  
  export type RunFunc<InteractionType> = {
    (client: Bot, inter: InteractionType): Promise<unknown>;
  };
  
  export type CommandFunc = RunFunc<ChatInputCommandInteraction<CacheType>>;
  export type AutocompleteFunc = RunFunc<AutocompleteInteraction<CacheType>>;
  
  export interface Command {
    data: SlashCommandBuilder;
    run: RunFunc<ChatInputCommandInteraction<CacheType>> | CommandFunc;
    autocomplete: RunFunc<AutocompleteInteraction<CacheType>> | AutocompleteFunc;
  }
  