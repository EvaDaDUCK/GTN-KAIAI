import { PrismaClient } from "@prisma/client";
import { ConsolaInstance } from "consola";
import Bot from "../Discord/Discord";

declare global {
  var logger: ConsolaInstance;
  var database: PrismaClient;
  var bot: Bot
  var events: Map<string, {id: number, value: number}>
}

export {};