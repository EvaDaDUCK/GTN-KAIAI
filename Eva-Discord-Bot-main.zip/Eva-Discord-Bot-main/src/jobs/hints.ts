import { TextChannel } from "discord.js"

export const interval = "*/1 * * * *"

export const run = async () => {
    var events = await global.database.event.findMany({})
    events.forEach(async event => {
        if (event.hintInterval == 0) {
            return
        }

        // atleast 3 minute in the event
        if (Date.now() - event.createdAt.getTime() <= 60e3 * 3) {
            return
        }

        let range = (event.max - event.min)
        let progress = (range > 700) ? 100 : 50; // if the range is higher than 700, do 100, otherwise 50

        if (progress >= range) {
            return
        }

        event.leftHintInterval--
        if (event.leftHintInterval != 0) {
            await global.database.event.updateMany({
                where: {
                    id: event.id
                },
                data: {
                    leftHintInterval: event.leftHintInterval
                }
            })

            return
        }

        event.leftHintInterval = event.hintInterval

        if (event.min + progress >= event.value) {
            // change currentMax
            event.max -= progress
        } else if (event.max - progress <= event.value) {
            event.min += progress
        } else {
            // pick a random side
            if (Math.random() >= 0.5) {
                event.max -= progress
            } else {
                event.min += progress
            }
        }

        await global.database.event.updateMany({
            where: {
                id: event.id
            },
            data: {
                leftHintInterval: event.leftHintInterval,
                min: event.min,
                max: event.max,
            }
        })

        const channel = (global.bot.channels.cache.get(event.channelID) || global.bot.channels.fetch(event.channelID)) as TextChannel
        if (channel && "send" in channel) {
            await channel.send({
                embeds: [global.bot.createEmbed({
                    title: `:tada: New hint!`,
                    description: `New range: **${event.min} - ${event.max}**`,
                })]
            })
        }
    })
}

