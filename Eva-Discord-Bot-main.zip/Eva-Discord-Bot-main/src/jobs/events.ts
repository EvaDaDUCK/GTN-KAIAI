export const interval = "*/1 * * * *"

export const runOnce = true

export const syncEvents = async () => {
    const events = await global.database.event.findMany({})
    let newEvents: Map<string, { id: number, value: number }> = new Map()
    events.map(event => {
        newEvents.set(event.channelID, { id: event.id, value: event.value })
    })

    if (process.env.DEV_MODE && global.events == null || global.events.size != newEvents.size) {
        global.logger.info(`Cached ${newEvents.size} events (drops)`)
    }

    global.events = newEvents
}

export const run = async () => {
    return syncEvents()
}

