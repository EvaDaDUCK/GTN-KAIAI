import { BaseInteraction, GuildMember, PermissionFlagsBits } from "discord.js"
import { ALLOWED_ROLES } from "../config"

export const userHasPermissions = async (interaction: BaseInteraction) => {
    if (!interaction.inGuild()) {
        return false
    }

    if (!interaction.member || !(interaction.member as GuildMember)) {
        return false
    }

    // check if user has any allowed role
    var hasRole = false
    ALLOWED_ROLES.forEach(role => {
        if ((interaction.member as GuildMember).roles.cache.some(r => r.id === role)) {
            hasRole = true
            return
        }
    })

    return hasRole
}