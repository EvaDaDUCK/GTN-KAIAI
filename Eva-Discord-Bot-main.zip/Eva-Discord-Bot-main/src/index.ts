import { GatewayIntentBits } from "discord.js"
import { createConsola } from "consola"
import cron from "node-cron";

import Bot from "./Discord/Discord";
import { PrismaClient } from "@prisma/client";
import fs from "fs"
import { Job } from "./types/Job";

async function init() {
    global.logger = createConsola({})
    global.database = new PrismaClient()

    // Create bot
    global.bot = new Bot({
        intents: [
            GatewayIntentBits.Guilds,
            GatewayIntentBits.GuildMessages,
            GatewayIntentBits.DirectMessages,
            GatewayIntentBits.MessageContent
        ]
    });

    await global.bot.start()

    // Create cron jobs
    const jobsFiles = fs.readdirSync(`${__dirname}/jobs`).filter(file => file.endsWith('.js') || file.endsWith('.ts'));
    for (const file of jobsFiles) {
        const job: Job = await import(`${__dirname}/jobs/${file}`)
        if ("interval" in job && "run" in job) {
            if (job.runOnce) {
                job.run()
            }
            
            cron.schedule(job.interval, job.run)
        } else {
            global.logger.error(
                `[WARNING] The job at ${file} is missing a required "interval" or "run" property.`
            );
        }
    }
}

init()